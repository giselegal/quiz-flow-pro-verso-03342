import { Block, BlockType } from '@/types/editor';
import { nanoid } from 'nanoid';
import { getBlockDefinition } from '@/core/blocks/registry';

/**
 * 🔧 Utilitários para geração de IDs e manipulação de blocos
 */

/**
 * Gera um ID único e consistente para blocos
 */
export const generateBlockId = (componentType: string): string => {
  return `block-${componentType}-${nanoid(8)}`;
};

/**
 * Calcula a próxima ordem para um bloco em uma lista
 */
export const getNextBlockOrder = (blocks: Block[]): number => {
  return (blocks?.length || 0) + 1;
};

/**
 * Cria um bloco a partir de um tipo de componente
 */
export const createBlockFromComponent = (
  componentType: BlockType,
  existingBlocks: Block[] = []
): Block => {
  const def = getBlockDefinition(componentType as any);
  const defaults = def?.defaultProps || {};
  return {
    id: generateBlockId(componentType),
    type: componentType,
    order: getNextBlockOrder(existingBlocks),
    content: {},
    properties: { ...defaults },
  };
};

/**
 * Duplica um bloco existente com novo ID e ordem
 */
export const duplicateBlock = (blockToDuplicate: Block, existingBlocks: Block[] = []): Block => {
  return {
    ...blockToDuplicate,
    id: generateBlockId(`${blockToDuplicate.type}-copy`),
    order: getNextBlockOrder(existingBlocks),
  };
};

/**
 * Função segura para clipboard com fallback
 */
export const copyToClipboard = async (text: string): Promise<boolean> => {
  try {
    const hasNavigator = typeof navigator !== 'undefined';
    const hasDocument = typeof document !== 'undefined';

    // Preferir API moderna quando disponível (sem exigir isSecureContext em testes/JSdom)
    if (hasNavigator && (navigator as any).clipboard?.writeText) {
      try {
        await (navigator as any).clipboard.writeText(text);
        return true;
      } catch (_) {
        // Continua para fallback
      }
    }

    if (hasDocument) {
      // Fallback para ambientes não-HTTPS
      const textArea = document.createElement('textarea');
      textArea.value = text;
      (textArea.style as any).position = 'fixed';
      (textArea.style as any).left = '-999999px';
      (textArea.style as any).top = '-999999px';
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();

      const success = document.execCommand('copy');
      document.body.removeChild(textArea);
      return success;
    }

    // Ambiente sem DOM (ex.: teste node) – não falha, apenas retorna false
    return false;
  } catch (err) {
    console.error('Failed to copy to clipboard:', err);
    return false;
  }
};

/**
 * Logger condicional para desenvolvimento
 */
export const devLog = (message: string, ...args: any[]): void => {
  if (process.env.NODE_ENV === 'development') {
    console.log(`🎯 [QuizEditor] ${message}`, ...args);
  }
};

/**
 * Valida se um JSON é um estado válido do editor
 */
export const validateEditorJSON = (jsonString: string): { valid: boolean; error?: string } => {
  try {
    const parsed = JSON.parse(jsonString);

    // Verificações básicas de estrutura
    if (!parsed || typeof parsed !== 'object') {
      return { valid: false, error: 'JSON deve ser um objeto' };
    }

    if (!parsed.stepBlocks || typeof parsed.stepBlocks !== 'object') {
      return { valid: false, error: 'JSON deve conter stepBlocks' };
    }

    if (typeof parsed.currentStep !== 'number' || parsed.currentStep < 1) {
      return { valid: false, error: 'currentStep deve ser um número positivo' };
    }

    return { valid: true };
  } catch (err) {
    return { valid: false, error: 'JSON inválido: ' + (err as Error).message };
  }
};
