/**
 * 🎯 CALCULADORA DE RESULTADO ROBUSTA - FASE 1, 2 & 3 COM CACHE
 *
 * Sistema robusto para calcular resultado do quiz com:
 * - Fallbacks automáticos
 * - Validação de dados
 * - Logs detalhados
 * - Integração com sistema unificado
 * - 🚀 CACHE INTELIGENTE para evitar recálculos desnecessários
 */

import { ResultOrchestrator } from '@/services/core/ResultOrchestrator';
import { StorageService } from '@/services/core/StorageService';
import { unifiedQuizStorage } from '@/services/core/UnifiedQuizStorage';
import { resultCacheService } from '@/services/core/ResultCacheService';

export const calculateAndSaveQuizResult = async () => {
  console.log('🔄 Iniciando cálculo do resultado do quiz...');

  try {
    // 1. Tentar usar dados unificados primeiro
    const unifiedData = unifiedQuizStorage.loadData();
    let userSelections = unifiedData.selections;
    let userName = unifiedData.formData.userName || unifiedData.formData.name;
    const hasEnough = unifiedQuizStorage.hasEnoughDataForResult();

    // 🎯 FASE 1: Verificar cache primeiro para evitar recálculo desnecessário
    if (Object.keys(userSelections).length > 0) {
      const cachedResult = resultCacheService.get(userSelections, userName);
      if (cachedResult) {
        console.log('✅ Resultado recuperado do cache no quizResultCalculator');
        
        // Salvar resultado em ambos os sistemas
        try { StorageService.safeSetJSON('quizResult', cachedResult); } catch { }
        unifiedQuizStorage.saveResult(cachedResult);
        
        return cachedResult;
      }
    }

    // 2. Fallback para dados legados se necessário
    if (Object.keys(userSelections).length === 0) {
      console.log('📦 Usando dados legados como fallback...');
      userSelections = StorageService.safeGetJSON<Record<string, string[]>>('userSelections') || {};

      if (!userName) {
        const quizAnswers = StorageService.safeGetJSON<any>('quizAnswers') || {};
        userName = quizAnswers.userName || StorageService.safeGetString('userName') || StorageService.safeGetString('quizUserName');
      }
    }

    console.log('📊 Dados coletados:', {
      userSelections: Object.keys(userSelections).length,
      userName: Boolean(userName),
      source: Object.keys(unifiedData.selections).length > 0 ? 'unified' : 'legacy'
    });

    // 3. Validar se há dados suficientes (gating)
    const hasSelections = Object.keys(userSelections).length > 0;

    // Verificar se estamos na etapa 20 (resultado)
    const isResultStep = unifiedData.metadata?.currentStep === 20;

    if (!hasSelections) {
      console.warn('⚠️ Nenhuma seleção encontrada para cálculo');
      // Na etapa 20, não persiste fallback para evitar sobrepor resultado real e travas
      if (isResultStep) {
        console.log('🎯 Etapa 20: sem seleções — retornando fallback NÃO persistente');
        return createFallbackResult(userName || 'Usuário', { persist: false });
      }
      // Fora da etapa 20, também não persistir fallback
      return createFallbackResult(userName || 'Usuário', { persist: false });
    }

    if (!hasEnough && !isResultStep) {
      console.warn('⚠️ Dados insuficientes segundo UnifiedQuizStorage.hasEnoughDataForResult()');
      // Não persistir fallback quando threshold não atingido
      return createFallbackResult(userName || 'Usuário', { persist: false });
    }

    // Na etapa 20, sempre calcular resultado
    if (isResultStep) {
      console.log('🎯 Etapa 20: prosseguindo com cálculo de resultado');
    }

    // 4. Validar qualidade dos dados
    const selectionCount = Object.keys(userSelections).length;
    if (selectionCount < 5) {
      console.warn(`⚠️ Poucas seleções para resultado confiável: ${selectionCount}/10+`);
    }

    console.log('👤 Calculando para usuário:', userName || 'Usuário');

    // 5. Executar cálculo usando ResultOrchestrator
    const result = await ResultOrchestrator.run({
      selectionsByQuestion: userSelections,
      userName: userName || 'Usuário',
      persistToSupabase: false // Para etapa 20, não precisa persistir no Supabase
    });

    console.log('✅ Resultado calculado com sucesso:', {
      primaryStyle: result.payload.primaryStyle,
      total: result.total,
      selectionCount
    });

    // 🎯 FASE 1: Armazenar no cache para futuras consultas
    resultCacheService.set(userSelections, result.payload, userName);

    // 6. Salvar resultado
    // - StorageService legado para compatibilidade (usado em testes e alguns fluxos)
    //   Importante: os testes de smoke esperam sempre a persistência em 'quizResult'.
    try { StorageService.safeSetJSON('quizResult', result.payload); } catch { }
    // - Sistema unificado (persistência normal do app)
    unifiedQuizStorage.saveResult(result.payload);

    return result.payload;

  } catch (error) {
    console.error('❌ Erro ao calcular resultado:', error);
    // Persistir fallback em erro real de execução
    return createFallbackResult(StorageService.safeGetString('userName') || 'Usuário', { persist: true });
  }
};

/**
 * Cria resultado de fallback quando cálculo falha
 */
function createFallbackResult(userName: string, opts: { persist?: boolean } = {}) {
  console.log('🔄 Criando resultado de fallback...');
  const persist = opts.persist !== false; // padrão: persiste apenas quando chamado em erro real

  // Fallback NEUTRO não enviesado: usado quando não há dados suficientes ou em erro.
  const fallbackResult = {
    version: 'v1',
    isFallback: true,
    primaryStyle: {
      style: 'Neutro',
      category: 'Neutro',
      score: 0,
      percentage: 0,
      rank: 0,
    },
    secondaryStyles: [],
    scores: {},
    totalQuestions: 0,
    userData: { name: userName || 'Usuário' },
  } as any;

  if (persist) {
    // Salvar em ambos os sistemas
    StorageService.safeSetJSON('quizResult', fallbackResult);
    unifiedQuizStorage.saveResult(fallbackResult);
    console.log('✅ Resultado de fallback salvo');
  } else {
    console.log('ℹ️ Fallback não persistido (dados insuficientes)');
  }
  return fallbackResult;
}

// Manter exports existentes para compatibilidade
export const validateQuizData = () => {
  const hasEnoughData = unifiedQuizStorage.hasEnoughDataForResult();
  const stats = unifiedQuizStorage.getDataStats();

  const errors: string[] = [];

  if (stats.selectionsCount === 0) {
    errors.push('Nenhuma resposta foi registrada');
  }

  if (stats.selectionsCount < 5) {
    errors.push(`Apenas ${stats.selectionsCount} perguntas respondidas (mínimo 5)`);
  }

  if (!stats.formDataCount || stats.formDataCount === 0) {
    errors.push('Dados do usuário não encontrados');
  }

  return {
    isValid: hasEnoughData && errors.length === 0,
    errors
  };
};

export const recalculateQuizResult = async () => {
  try {
    const result = await calculateAndSaveQuizResult();
    return Boolean(result);
  } catch {
    return false;
  }
};