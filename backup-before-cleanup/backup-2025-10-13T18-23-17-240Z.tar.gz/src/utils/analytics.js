// LEGACY FILE STUB - All analytics functionality moved to analytics.ts
// This file exists only to prevent 404s during hot reload. Can be deleted safely.
export * from './analytics.ts';
