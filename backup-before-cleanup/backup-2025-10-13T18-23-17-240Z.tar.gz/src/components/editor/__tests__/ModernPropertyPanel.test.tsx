import { describe, it } from 'vitest';

describe.skip('ModernPropertyPanel (placeholder)', () => {
  it('placeholder', () => {});
});
