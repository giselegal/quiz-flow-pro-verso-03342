import React from 'react';

const LeadFormBlock: React.FC = () => {
  return (
    <div className="p-4 border rounded bg-white">
      <h4 className="font-medium">Lead Form (stub)</h4>
      <p className="text-sm text-gray-500">Componente placeholder para LeadFormBlock.</p>
    </div>
  );
};

export default LeadFormBlock;
