// Quiz components exports
export const QUIZ_COMPONENTS = {
  intro: 'QuizIntroBlock',
  optionsGrid: 'QuizOptionsGridBlock',
  multipleChoice: 'QuizMultipleChoiceBlock',
  result: 'QuizResultBlock',
};
